"use strict";

document.addEventListener("DOMContentLoaded", init);

function init(){

}